/**
 * Created by jubae on 09/27/2017.
 */
public class routs {

    public static void main(String arg[]){
        /**
         * Suppose we have 3 places(A, B & C).
         * We have to travel from A to C.
         * There are 4 possible rout for do this.
         * 1. A-C
         * 2. A-(B-C)1
         * 3. A-(B-C)2
         * 4. A-(B-C)3
         */
        double ab=2, ac=6, bc1=2, bc2=3, bc3=3.5;//routs(between two place) costs.
        int ab_v=1, ac_v=1, bc1_v=1, bc2_v=1, bc_3_v=1;
        double rout1=ac*ac_v, rout2;

    }

}
